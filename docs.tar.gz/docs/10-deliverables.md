# 10 — Deliverables: README.md, USER_DOC.md, DEV_DOC.md

Three Markdown files at the **repo root**, in English `[S p.12–14]`. They are
graded. Most of the content already exists in this `docs/` folder — condense it,
don't copy-paste it.

---

## README.md `[S p.12–13]`

Required, in this order:

```markdown
*This project has been created as part of the 42 curriculum by <login>.*

# Inception

## Description
<!-- goal + short overview: 3 services, TLS entrypoint, volumes, network -->

## Instructions
<!-- prerequisites (VM, Docker, /etc/hosts), create srcs/.env + secrets/, make / make down / make fclean -->

## Project description
<!-- how Docker is used, what the sources contain (one line per service folder),
     main design choices (Alpine 3.23, entrypoint pattern, secrets, volumes A vs B) -->

### Virtual Machines vs Docker
### Secrets vs Environment Variables
### Docker Network vs Host Network
### Docker Volumes vs Bind Mounts

## Resources
<!-- doc links (reuse the [DOC] links from docs/) -->

### AI usage
<!-- which tasks, which parts of the project — be specific and honest -->
```

| Requirement | Source | Where to take it from |
|---|---|---|
| First line, **italic**, exact sentence | `[S p.12]` | — |
| Description / Instructions / Resources sections | `[S p.12]` | 00, 03, 08 |
| Use of Docker + sources included + design choices | `[S p.12]` | 00 conventions, 05–08 `[CHOICE]` tags |
| The 4 comparisons | `[S p.12]` | [02 — Concepts](02-concepts.md) (one table each) |
| AI usage: for which tasks and which parts | `[S p.12]` | your own honest list |
| English | `[S p.13]` | — |

**AI usage — example of a precise answer** (adapt to what you actually did):
> AI (Claude) was used to draft this roadmap in `docs/`, to cross-check package
> names against the Alpine index, and to review the Compose file. All
> Dockerfiles, configs and scripts were written and tested by me; every line
> was verified against the linked documentation.

---

## USER_DOC.md `[S p.14]`

Audience: an end user / admin who doesn't care about Dockerfiles. Must cover:

| Must explain | Content |
|---|---|
| What services the stack provides | NGINX (HTTPS entrypoint), WordPress + php-fpm (site), MariaDB (database) |
| Start and stop | `make` · `make down` |
| Access the website and admin panel | `https://<login>.42.fr` · `https://<login>.42.fr/wp-admin` · accept the self-signed cert |
| Locate and manage credentials | `secrets/*.txt` (passwords), `srcs/.env` (usernames); how to change one (edit → `make fclean && make`, and why fclean) |
| Check services are running | `docker compose -f srcs/docker-compose.yml ps` (mariadb "healthy") · `docker logs <svc>` · `curl -kI https://<login>.42.fr` |

---

## DEV_DOC.md `[S p.14]`

Audience: a developer setting it up from scratch. Must cover:

| Must explain | Content |
|---|---|
| Set up from scratch: prerequisites, config files, secrets | [03](03-vm-setup.md) + [04](04-layout-env-secrets.md): VM, Docker, `/etc/hosts`, `cp .env.example .env`, generate secrets |
| Build and launch with Makefile + Compose | [08](08-compose-makefile.md): `make` = `docker compose … up -d --build`; each target |
| Commands to manage containers and volumes | `ps`, `logs`, `exec`, `docker volume ls/inspect`, `make clean/fclean` |
| Where data is stored and how it persists | `/home/<login>/data/{mariadb,wordpress}` via named volumes; survives `down`, deleted by `fclean` |

---

## Checklist

- [ ] `README.md` first line is italic and exact
- [ ] 4 comparisons present
- [ ] AI usage section is specific
- [ ] `USER_DOC.md` covers its 5 points
- [ ] `DEV_DOC.md` covers its 4 points
- [ ] All three in English, at the repo root

---

### Quick Reference
- **README first line:** `*This project has been created as part of the 42 curriculum by <login>.*`
- **README sections:** Description · Instructions · Project description (+4 comparisons) · Resources (+AI usage)
- **USER_DOC:** services · start/stop · URLs · credentials · health checks
- **DEV_DOC:** setup from scratch · make/compose · management commands · data location & persistence
