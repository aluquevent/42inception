# 08 — docker-compose.yml + Makefile

Goal: `make` builds the 3 images and starts the stack; `make fclean` returns the
VM to zero. The Makefile calls Compose, Compose calls the Dockerfiles `[S p.4]` `[S p.7]`.

---

## 1. `srcs/docker-compose.yml`

```yaml
name: inception

services:
  mariadb:
    container_name: mariadb
    image: mariadb:inception
    build: requirements/mariadb
    env_file: .env
    secrets:
      - db_root_password
      - db_password
    volumes:
      - mariadb_data:/var/lib/mysql
    networks:
      - inception
    restart: always
    healthcheck:
      test: ["CMD", "mariadb-admin", "ping", "-h", "127.0.0.1", "--silent"]
      interval: 5s
      timeout: 3s
      retries: 10

  wordpress:
    container_name: wordpress
    image: wordpress:inception
    build: requirements/wordpress
    env_file: .env
    secrets:
      - db_password
      - wp_admin_password
      - wp_user_password
    volumes:
      - wordpress_data:/var/www/html
    networks:
      - inception
    depends_on:
      mariadb:
        condition: service_healthy
    restart: always

  nginx:
    container_name: nginx
    image: nginx:inception
    build: requirements/nginx
    env_file: .env
    ports:
      - "443:443"
    volumes:
      - wordpress_data:/var/www/html
    networks:
      - inception
    depends_on:
      - wordpress
    restart: always

volumes:
  mariadb_data:
    name: mariadb_data
    driver: local
    driver_opts:
      type: none
      o: bind
      device: ${DATA_PATH}/mariadb
  wordpress_data:
    name: wordpress_data
    driver: local
    driver_opts:
      type: none
      o: bind
      device: ${DATA_PATH}/wordpress

networks:
  inception:
    name: inception
    driver: bridge

secrets:
  db_root_password:
    file: ../secrets/db_root_password.txt
  db_password:
    file: ../secrets/db_password.txt
  wp_admin_password:
    file: ../secrets/wp_admin_password.txt
  wp_user_password:
    file: ../secrets/wp_user_password.txt
```

Reference for every key: `[DOC]` https://docs.docker.com/reference/compose-file/services/ ·
https://docs.docker.com/reference/compose-file/volumes/ ·
https://docs.docker.com/reference/compose-file/networks/ ·
https://docs.docker.com/reference/compose-file/secrets/

### Service keys — why

| Key | Why | Source |
|---|---|---|
| `container_name` = `image` name = service name | "same name as its corresponding service" | `[S p.7]` |
| `image: <svc>:inception` | Names the image *we build*; explicit tag so it's never `latest`. Without a tag, Docker defaults to `latest` | `[S p.8]` · `[DOC]` https://docs.docker.com/reference/cli/docker/image/tag/ |
| `build: requirements/<svc>` | Our own Dockerfile. Relative to the compose file's folder | `[S p.7]` |
| `env_file: .env` | Injects the non-secret vars into the container | `[S p.8]` · `[DOC]` services → env_file |
| `secrets:` per service | Only what each one needs (nginx: none) | `[DOC]` use-secrets: "per-service basis" |
| `networks: [inception]` | The `network` line must be present | `[S p.8]` |
| `restart: always` | Restart on crash. `[CHOICE]` `always` over `on-failure` because `on-failure` ignores a crash that exits 0; over `unless-stopped` because the defense may reboot the VM / daemon | `[S p.7]` · `[DOC]` services → restart |
| `ports: "443:443"` on nginx **only** | Single entrypoint, port 443 only | `[S p.8]` |
| `depends_on` + `condition: service_healthy` | WordPress's `wp config create` needs a live DB. Compose "waits for healthchecks to pass" | `[DOC]` services → depends_on |
| Plain `depends_on: [wordpress]` on nginx | nginx resolves `wordpress` at start; the container must exist | `[DOC]` services → depends_on |

### The healthcheck — why it's correct

```yaml
test: ["CMD", "mariadb-admin", "ping", "-h", "127.0.0.1", "--silent"]
```
- `-h 127.0.0.1` forces **TCP**. During init the temp server runs with
  `--skip-networking` (05), so TCP fails → not healthy yet. It passes only once the
  **real** `mariadbd` is up. Using the socket (`localhost`) would pass too early.
- No credentials needed: `ping` exits 0 even on "Access denied", because that
  still means the server is up. `[DOC]` mariadb-admin man page:
  https://manpages.opensuse.org/Leap-15.6/mariadb-client/mariadb-admin.1.en.html
  (see also https://jira.mariadb.org/browse/MDEV-31550 — behaviour reported, keep an eye on it).
- `["CMD", …]` exec form, no shell. `[DOC]` services → healthcheck.

### `${DATA_PATH}` interpolation

Compose substitutes `${VAR}` from the `.env` in the project directory. With
`-f srcs/docker-compose.yml` that directory is `srcs/`, so it reads `srcs/.env`.
`[DOC]` https://docs.docker.com/compose/how-tos/environment-variables/variable-interpolation/
`[LOCAL]` `docker compose -f srcs/docker-compose.yml config` prints the resolved file.

### Volumes — the grey area

The subject says, at the same time `[S p.7]`:
1. "You must use Docker **named volumes**" — "Bind mounts are **not allowed**"
2. Both volumes "must store their data inside `/home/login/data`"

A plain named volume stores data in Docker's own dir (`/var/lib/docker/volumes/…`),
not in `/home/<login>/data`. Two ways to satisfy both:

**A — `driver_opts` bind (what we use)** `[CHOICE]` `[COMMON]`
```yaml
driver: local
driver_opts: { type: none, o: bind, device: ${DATA_PATH}/mariadb }
```
- It **is** a named volume: declared top-level, listed by `docker volume ls`,
  inspected/removed through the volume API, referenced by name in services.
- The `local` driver backs it with a host directory. This exact example is in
  `[DOC]` https://docs.docker.com/reference/compose-file/volumes/ (`driver_opts`).
- What the subject forbids is the service-level bind mount syntax
  `- /home/<login>/data/mariadb:/var/lib/mysql`. We never use that.
- ⚠️ Some evaluators argue it's "a bind mount in disguise". Have argument A
  ready, and **ask peers how your campus grades it**.

**B — move Docker's data root** (purist alternative)
Set `"data-root": "/home/<login>/data"` in `/etc/docker/daemon.json`; plain
named volumes then live under `/home/<login>/data/volumes/`.
`[DOC]` https://docs.docker.com/reference/cli/dockerd/ (`--data-root`)
Cost: *all* of Docker (images, containers) moves there, and it's a VM config
change outside the repo, so `make` alone can't reproduce it.

We go with **A**: it's reproducible from the repo, and you can explain it.

`name: mariadb_data` — fixed name, so Compose doesn't prefix it with the project
name. "The name is used as is and is not scoped with the stack name." `[DOC]` volumes page.

### Network

```yaml
networks:
  inception:
    name: inception
    driver: bridge
```
User-defined bridge → DNS by service name ([02](02-concepts.md#docker-network-vs-host-network--readme-comparison-3)).
No `network_mode: host`, no `links` `[S p.8]`.

### Secrets

`file:` paths are relative to the compose file → `../secrets/` is the repo-root
`secrets/` folder `[S p.10]`. Mounted at `/run/secrets/<name>`. `[DOC]` use-secrets.

---

## 2. `Makefile` (repo root)

```make
COMPOSE  := docker compose -f srcs/docker-compose.yml
ENV_FILE := srcs/.env

include $(ENV_FILE)

all: up

up: dirs
	$(COMPOSE) up -d --build

dirs:
	mkdir -p $(DATA_PATH)/mariadb $(DATA_PATH)/wordpress

down:
	$(COMPOSE) down

clean:
	$(COMPOSE) down --rmi all -v

fclean: clean
	sudo rm -rf $(DATA_PATH)

re: fclean all

.PHONY: all up dirs down clean fclean re
```

**Why each part:**
- `include $(ENV_FILE)` — the Makefile reads `DATA_PATH` from the **same**
  `.env` as Compose → one source of truth. That's why `.env` stays in plain
  `KEY=value` form (04). If `.env` is missing, `make` stops with a clear error.
  `[DOC]` https://www.gnu.org/software/make/manual/html_node/Include.html
- `dirs` before `up` — the volume `device` "must … already exist" `[DOC]` volumes page.
- `up -d --build` — always rebuild images from the Dockerfiles `[S p.7]`, run detached.
  `[DOC]` https://docs.docker.com/reference/cli/docker/compose/up/
- `down` — stop + remove containers and network. Volumes and data kept.
- `clean` — also `--rmi all` (our images) and `-v` (the named volumes).
  `[DOC]` https://docs.docker.com/reference/cli/docker/compose/down/
  Removing a `driver_opts: bind` volume does **not** delete the host files.
- `fclean` — deletes `/home/<login>/data`. `sudo` because the files are owned by
  container users (`mysql`, `nobody`), not you. `[CHOICE]` scoped to *this*
  project — no `docker system prune -a`, which would wipe everything on the VM.
- Recipe lines start with a **TAB**, not spaces.

---

## 3. First run

```sh
make
docker compose -f srcs/docker-compose.yml ps     # 3 containers, mariadb "healthy"
docker logs -f wordpress                         # watch the install
```
Open `https://<login>.42.fr` → accept the certificate → WordPress home page.
Admin panel: `https://<login>.42.fr/wp-admin`.

---

## Checklist

- [ ] `make` from a clean VM brings up 3 containers
- [ ] `make down && make` → site and posts still there (persistence)
- [ ] `make fclean && make` → fresh install works
- [ ] `docker volume inspect mariadb_data` shows `device: /home/<login>/data/mariadb`
- [ ] Only port 443 published (`docker ps` PORTS column)

---

### Quick Reference
- **Run:** `make` · **stop:** `make down` · **reset:** `make fclean` · **rebuild all:** `make re`
- **Compose:** `docker compose -f srcs/docker-compose.yml <ps|logs|config|exec>`
- **Per service:** `container_name` = `image name` = service; tag `:inception`
- **Volume:** `driver: local` + `driver_opts {type: none, o: bind, device: $DATA_PATH/x}`
- **Order:** mariadb (healthy) → wordpress → nginx
- **Only `ports:`** → nginx `443:443`
