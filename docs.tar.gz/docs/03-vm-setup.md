# 03 — VM setup

Goal: a VM where `docker compose version` works, `/home/<login>/data` exists, and
`<login>.42.fr` resolves to the VM.

---

## 1. The VM

- **Required:** the project runs in a VM `[S p.4]` `[S p.7]`.
- **OS:** Debian 13 "Trixie" (current stable) `[CHOICE]`. Reason: officially
  supported by Docker's install guide, minimal, you likely know it from
  Born2beRoot. `[DOC]` https://www.debian.org/releases/ ·
  https://docs.docker.com/engine/install/debian/ (lists Trixie 13 and Bookworm 12).
- The VM's OS is **not** the container base image. The "penultimate" rule
  `[S p.7]` applies to the `FROM` line, not to the VM.
- Give it a desktop or at least a browser, so you can open `https://<login>.42.fr`
  during the defense `[COMMON]`.
- Your VM username should be your 42 login, so `/home/<login>` is your home `[COMMON]`.

## 2. Install Docker Engine + Compose plugin

Follow the official guide: `[DOC]` https://docs.docker.com/engine/install/debian/
(section "Install using the apt repository"). The final install line it gives:

```sh
sudo apt install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
```

- `docker-compose-plugin` gives you `docker compose` (with a space) — the v2
  command the subject uses `[S p.7]`. Don't install the old `docker-compose` binary.

Let your user run docker without sudo:
`[DOC]` https://docs.docker.com/engine/install/linux-postinstall/
```sh
sudo usermod -aG docker $USER    # then log out and back in
```

Check:
```sh
docker run --rm alpine:3.23 echo ok   # pulling alpine is allowed [S p.7]
docker compose version
```

## 3. Data directories

The two volumes store their data in `/home/<login>/data` `[S p.7]`. The Makefile
will create the subfolders (see [08](08-compose-makefile.md)), but you can test now:

```sh
mkdir -p /home/<login>/data/mariadb /home/<login>/data/wordpress
```

Why they must exist *before* `docker compose up`: the volume options we use
require it — the Compose docs mark `device` as "must be the absolute host path
and already exist". `[DOC]` https://docs.docker.com/reference/compose-file/volumes/

## 4. The domain

`<login>.42.fr` must point to your local IP `[S p.8]`. No real DNS — use the
hosts file on the **VM** (where the browser runs):

```sh
echo "127.0.0.1 <login>.42.fr" | sudo tee -a /etc/hosts
getent hosts <login>.42.fr            # → 127.0.0.1 <login>.42.fr
```

- `/etc/hosts` is checked before DNS on a default Linux setup `[COMMON]`
  (`[LOCAL]` see the `hosts:` line in `/etc/nsswitch.conf`).
- If you browse from the *host* machine instead, put the VM's IP in the host's
  hosts file and forward port 443.

## 5. Get the repo into the VM

```sh
git clone <your-repo> ~/inception
```
Everything from now on happens **inside the VM**.

---

## Checklist

- [ ] VM running Debian 13 (or your chosen OS)
- [ ] `docker compose version` works without sudo
- [ ] `/home/<login>/data/{mariadb,wordpress}` exist
- [ ] `getent hosts <login>.42.fr` returns 127.0.0.1
- [ ] Repo cloned in the VM

---

### Quick Reference
- **Install:** follow docs.docker.com/engine/install/debian → `apt install docker-ce … docker-compose-plugin`
- **No sudo:** `sudo usermod -aG docker $USER` + re-login
- **Data:** `mkdir -p /home/<login>/data/{mariadb,wordpress}`
- **Domain:** `127.0.0.1 <login>.42.fr` in `/etc/hosts`
- **Compose v2 command:** `docker compose` (space), not `docker-compose`
