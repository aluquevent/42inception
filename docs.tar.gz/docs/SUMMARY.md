# Summary

[Index](00-index.md)

# Understand

- [01 — Requirements](01-requirements.md)
- [02 — Concepts](02-concepts.md)

# Build

- [03 — VM setup](03-vm-setup.md)
- [04 — Layout, .env, secrets](04-layout-env-secrets.md)
- [05 — MariaDB](05-mariadb.md)
- [06 — WordPress](06-wordpress.md)
- [07 — NGINX](07-nginx.md)
- [08 — Compose + Makefile](08-compose-makefile.md)

# Ship

- [09 — Validation](09-validation.md)
- [10 — Deliverables](10-deliverables.md)
- [11 — Bonus](11-bonus.md)
