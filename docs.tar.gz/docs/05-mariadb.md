# 05 — MariaDB

Goal: a container running **only MariaDB** `[S p.7]`, reachable on port 3306 from
the `inception` network, with the WordPress database and user created on first run.

Files:
```
srcs/requirements/mariadb/
├── Dockerfile
├── .dockerignore
├── conf/mariadb-server.cnf
└── tools/entrypoint.sh
```

---

## 1. Facts this is built on

| Fact | Source |
|---|---|
| Package `mariadb` = 11.4.x on Alpine 3.23 | `[PKG]` https://pkgs.alpinelinux.org/packages?name=mariadb&branch=v3.23 |
| Binaries: `/usr/bin/mariadbd`, `/usr/bin/mariadb-install-db` | `[PKG]` contents of `mariadb` (v3.23) |
| Default server config: `/etc/my.cnf.d/mariadb-server.cnf` (from `mariadb-common`) | `[PKG]` contents of `mariadb-common` (v3.23) |
| `mariadb-install-db` creates the data dir + system tables | `[DOC]` https://mariadb.com/docs/server/clients-and-utilities/deployment-tools/mariadb-install-db |
| `skip-networking` → no TCP at all; `bind-address` = which IP it listens on | `[DOC]` https://mariadb.com/docs/server/mariadb-quickstart-guides/mariadb-remote-connection-guide |
| Init pattern: temp server with `--skip-networking`, run SQL over socket, stop it, `exec` the real one | `[DOC]` official image entrypoint https://github.com/MariaDB/mariadb-docker/blob/master/docker-entrypoint.sh (`docker_temp_server_start`, `docker_temp_server_stop`) |

---

## 2. `conf/mariadb-server.cnf`

Replaces Alpine's file of the same name (convention #5).

```ini
[client-server]
socket = /run/mysqld/mysqld.sock
port   = 3306

[mysqld]
user            = mysql
datadir         = /var/lib/mysql
bind-address    = 0.0.0.0
skip-networking = 0
```

**Why each line:**
- `[client-server]` — a group read by **both** the server and the clients
  (`mariadb`, `mariadb-admin`), so both agree on the socket path. `[LOCAL]`
  `mariadbd --help --verbose` prints the groups it reads.
- `bind-address = 0.0.0.0` — listen on all interfaces of the container so
  WordPress can connect from another container. Port 3306 is **not** published
  to the host (no `ports:`), so only the `inception` network can reach it.
- `skip-networking = 0` — make sure TCP is on (`[DOC]` remote-connection guide above).
- `datadir = /var/lib/mysql` — this is where the named volume is mounted (08).

---

## 3. `Dockerfile`

```dockerfile
FROM alpine:3.23

RUN apk add --no-cache mariadb mariadb-client

COPY conf/mariadb-server.cnf /etc/my.cnf.d/mariadb-server.cnf
COPY tools/entrypoint.sh /usr/local/bin/entrypoint.sh
RUN chmod +x /usr/local/bin/entrypoint.sh

EXPOSE 3306

ENTRYPOINT ["/usr/local/bin/entrypoint.sh"]
```

Piece by piece:
- `apk add --no-cache` — installs without keeping the package index in the image
  (smaller layer). `[DOC]` https://wiki.alpinelinux.org/wiki/Alpine_Package_Keeper
- `mariadb-client` — provides `mariadb` and `mariadb-admin`, used by the
  entrypoint and the healthcheck.
- `EXPOSE 3306` — **documentation only**, doesn't publish anything.
  `[DOC]` https://docs.docker.com/reference/dockerfile/#expose
- No password anywhere `[S p.8]` — they arrive at runtime as secrets.

---

## 4. `tools/entrypoint.sh`

```sh
#!/bin/sh
set -e

DB_ROOT_PASSWORD="$(cat /run/secrets/db_root_password)"
DB_PASSWORD="$(cat /run/secrets/db_password)"

mkdir -p /run/mysqld
chown -R mysql:mysql /run/mysqld /var/lib/mysql

if [ ! -d /var/lib/mysql/mysql ]; then
    mariadb-install-db --user=mysql --datadir=/var/lib/mysql --skip-test-db > /dev/null

    mariadbd --user=mysql --skip-networking &
    pid="$!"

    i=0
    until mariadb-admin ping --silent 2> /dev/null; do
        i=$((i + 1))
        if [ "$i" -ge 30 ]; then
            echo "mariadb: temporary server did not start" >&2
            exit 1
        fi
        sleep 1
    done

    mariadb -u root <<EOF
CREATE DATABASE IF NOT EXISTS \`${MYSQL_DATABASE}\`;
CREATE USER IF NOT EXISTS '${MYSQL_USER}'@'%' IDENTIFIED BY '${DB_PASSWORD}';
GRANT ALL PRIVILEGES ON \`${MYSQL_DATABASE}\`.* TO '${MYSQL_USER}'@'%';
ALTER USER 'root'@'localhost' IDENTIFIED BY '${DB_ROOT_PASSWORD}';
FLUSH PRIVILEGES;
EOF

    kill "$pid"
    wait "$pid"
fi

exec mariadbd --user=mysql
```

**Walkthrough:**

1. **Read secrets** — convention #4. `MYSQL_DATABASE` / `MYSQL_USER` come from `.env` via `env_file`.
2. **`/run/mysqld`** — the socket directory; must exist and belong to `mysql`.
   `chown /var/lib/mysql` because the volume's host folder is created by you
   (owned by your user), not by `mysql`.
3. **First-run guard** `[ ! -d /var/lib/mysql/mysql ]` — the `mysql` system
   database only exists after initialization. Second start (restart, `make` again)
   → skip straight to `exec`. Data persists in the volume.
4. **`mariadb-install-db`** — creates system tables. `--skip-test-db`: no
   useless `test` database. `[DOC]` mariadb-install-db page.
5. **Temp server with `--skip-networking`** — only the local socket is open, so
   nobody (WordPress, the healthcheck) can connect over TCP while we're still
   configuring. Same pattern as the official image `[DOC]` entrypoint link above.
6. **Bounded wait loop** — max 30 tries, then `exit 1`. This is **not** the
   forbidden `while true` `[S p.8]`: it ends, and it isn't what keeps the container
   alive — `mariadbd` is. Same as the official image (30 polls).
7. **SQL heredoc:**
   - `mariadb -u root` works without a password here because, on a fresh install,
     `root@localhost` authenticates through the Unix socket as the OS root user
     (the script runs as root). `[DOC]` https://mariadb.com/docs/server/security/user-account-management/authentication-from-mariadb-10-4
     `[LOCAL]` `SELECT user,host,plugin FROM mysql.global_priv;` before changing it.
   - `'${MYSQL_USER}'@'%'` — `%` = any host, because WordPress connects from
     *another container*, not from localhost.
   - `` \`${MYSQL_DATABASE}\` `` — backticks quote the identifier; escaped with
     `\` so the shell doesn't treat them as command substitution.
   - `ALTER USER root … IDENTIFIED BY` — root now needs the password.
8. **`kill` + `wait`** — stop the temp server cleanly before starting the real one.
9. **`exec mariadbd --user=mysql`** — becomes PID 1, foreground, TCP on (no
   `--skip-networking` this time). See [02 — PID 1](02-concepts.md#pid-1-and-daemons).

> If the first run fails halfway, the guard thinks it's initialized.
> Fix: `make fclean` (wipes `/home/<login>/data`) and start again.

---

## 5. Test it alone (before Compose)

```sh
cd srcs/requirements/mariadb
docker build -t mariadb:inception .
```
A full test needs secrets and env, which Compose provides → the real test is in
[08](08-compose-makefile.md). Once the stack runs:

```sh
docker exec -it mariadb mariadb -u root -p          # root password from secrets/
SHOW DATABASES;                                    -- 'wordpress' is there
SELECT user, host FROM mysql.user;                 -- 'wpuser'@'%' is there
```

---

## Checklist

- [ ] Image builds from `alpine:3.23`
- [ ] No password in the Dockerfile
- [ ] First start creates DB + user; second start skips init
- [ ] `mariadbd` is PID 1 (`docker exec mariadb ps` → PID 1 is `mariadbd`)
- [ ] Root login without password fails; with password works

---

### Quick Reference
- **Packages:** `mariadb mariadb-client`
- **Config:** `/etc/my.cnf.d/mariadb-server.cnf` → `bind-address=0.0.0.0`, `skip-networking=0`
- **Data dir:** `/var/lib/mysql` (volume) · **socket:** `/run/mysqld/mysqld.sock`
- **Init once:** `mariadb-install-db` → temp `mariadbd --skip-networking &` → SQL → `kill; wait`
- **Run:** `exec mariadbd --user=mysql`
- **User for WP:** `'user'@'%'` (any host), `GRANT ALL ON db.*`
