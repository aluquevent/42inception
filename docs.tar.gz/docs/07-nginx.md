# 07 — NGINX

Goal: the **only entrypoint** of the stack, on **port 443 only**, **TLSv1.2/1.3
only** `[S p.7]` `[S p.8]`. Serves static files from the WordPress volume and
passes `.php` to `wordpress:9000` `[S p.9]`.

Files:
```
srcs/requirements/nginx/
├── Dockerfile
├── .dockerignore
├── conf/nginx.conf
└── tools/entrypoint.sh      # renamed from script.sh, sh instead of bash
```

---

## 1. Facts this is built on

| Fact | Source |
|---|---|
| Package `nginx` = 1.28.x on Alpine 3.23 | `[PKG]` https://pkgs.alpinelinux.org/packages?name=nginx&branch=v3.23 |
| Ships `/etc/nginx/nginx.conf`, `/etc/nginx/fastcgi.conf`, `/etc/nginx/mime.types` | `[PKG]` contents of `nginx` (v3.23) |
| HTTPS server: `listen 443 ssl`, `ssl_certificate`, `ssl_certificate_key`, `ssl_protocols TLSv1.2 TLSv1.3` | `[DOC]` https://nginx.org/en/docs/http/configuring_https_servers.html |
| `daemon on\|off` — default `on` | `[DOC]` https://nginx.org/en/docs/ngx_core_module.html#daemon |
| `fastcgi_pass` takes `host:port` | `[DOC]` https://nginx.org/en/docs/http/ngx_http_fastcgi_module.html |
| WordPress rules: `try_files $uri $uri/ /index.php?$args;` and `include fastcgi.conf` for `.php` | `[DOC]` https://developer.wordpress.org/advanced-administration/server/web-server/nginx/ |

---

## 2. `conf/nginx.conf`

`[CHOICE]` We replace the **whole** `nginx.conf` (convention #5) instead of
dropping a file in an include dir. Reason: one file = the entire server
behaviour, nothing hidden in defaults you didn't read.

```nginx
user nginx;
worker_processes auto;
pid /run/nginx.pid;
daemon off;

error_log /dev/stderr warn;

events {
    worker_connections 1024;
}

http {
    include      /etc/nginx/mime.types;
    default_type application/octet-stream;
    access_log   /dev/stdout;

    server {
        listen      443 ssl;
        listen      [::]:443 ssl;
        server_name __DOMAIN_NAME__;

        ssl_certificate     /etc/nginx/ssl/inception.crt;
        ssl_certificate_key /etc/nginx/ssl/inception.key;
        ssl_protocols       TLSv1.2 TLSv1.3;

        root  /var/www/html;
        index index.php index.html;

        location / {
            try_files $uri $uri/ /index.php?$args;
        }

        location ~ \.php$ {
            include      /etc/nginx/fastcgi.conf;
            fastcgi_pass wordpress:9000;
        }
    }
}
```

**Main context:**
- `user nginx;` — workers run as the `nginx` user the Alpine package creates
  (`[LOCAL]` `grep nginx /etc/passwd` in the container).
- `pid /run/nginx.pid;` — explicit path in a dir that exists, so you don't depend
  on the package's compiled-in default.
- `daemon off;` — **foreground → PID 1** ([02 — PID 1](02-concepts.md#pid-1-and-daemons)).
  The nginx docs call it "mainly used during development"; in containers it's
  the standard way. `[COMMON]`
- `error_log /dev/stderr` + `access_log /dev/stdout` — convention #8, visible with `docker logs nginx`.

**Server block:**
- `listen 443 ssl` — HTTPS only. There is **no** `listen 80`: the subject wants
  443 only `[S p.8]`. Port 80 isn't published either (08).
- `server_name __DOMAIN_NAME__` — placeholder replaced at start by the entrypoint
  with `$DOMAIN_NAME` from `.env` (the only runtime substitution, convention #5).
- `ssl_protocols TLSv1.2 TLSv1.3` — nginx's docs say this is already the
  default, but the subject requires these only, so we **write it explicitly**
  — the evaluator will look for it. `[S p.7]` `[DOC]` configuring_https_servers.
- `root /var/www/html` — the `wordpress_data` volume, mounted in this container too (08).
- `location /` + `try_files` — real file → serve it; otherwise hand it to
  `index.php` (WordPress pretty permalinks). `[DOC]` WordPress nginx page.
- `location ~ \.php$` — regex: any URI ending in `.php`.
  - `include /etc/nginx/fastcgi.conf` — sets the standard FastCGI params,
    **including `SCRIPT_FILENAME`** (= `$document_root$fastcgi_script_name`), which
    PHP uses to find the script. `[LOCAL]` `cat /etc/nginx/fastcgi.conf`.
    (`fastcgi_params` — the other file — does *not* set `SCRIPT_FILENAME`.)
  - `fastcgi_pass wordpress:9000` — service name + php-fpm port.

> Paths must match in **both** containers: nginx sends
> `SCRIPT_FILENAME=/var/www/html/index.php`, and php-fpm opens that path in
> *its* filesystem. That's why the volume is mounted at `/var/www/html` in both.

---

## 3. `Dockerfile`

```dockerfile
FROM alpine:3.23

RUN apk add --no-cache nginx openssl

COPY conf/nginx.conf /etc/nginx/nginx.conf
COPY tools/entrypoint.sh /usr/local/bin/entrypoint.sh
RUN chmod +x /usr/local/bin/entrypoint.sh

EXPOSE 443

ENTRYPOINT ["/usr/local/bin/entrypoint.sh"]
```

- `openssl` — to generate the self-signed certificate.
- Fixes the old `alpine:3.22` and the `apk update &&` (redundant with `--no-cache`,
  which fetches a fresh index anyway). `[DOC]` https://wiki.alpinelinux.org/wiki/Alpine_Package_Keeper

---

## 4. `tools/entrypoint.sh`

```sh
#!/bin/sh
set -e

SSL_DIR=/etc/nginx/ssl

if [ ! -f "$SSL_DIR/inception.crt" ]; then
    mkdir -p "$SSL_DIR"
    openssl req -x509 -noenc -newkey rsa:2048 -days 365 \
        -keyout "$SSL_DIR/inception.key" \
        -out "$SSL_DIR/inception.crt" \
        -subj "/CN=$DOMAIN_NAME"
fi

sed -i "s/__DOMAIN_NAME__/$DOMAIN_NAME/" /etc/nginx/nginx.conf

exec nginx
```

**Walkthrough:**
- **No secrets** here — nginx needs none, so it's granted none (08).
- **Certificate at runtime, not build time** `[CHOICE]`: the private key never ends
  up baked in an image layer, and the CN uses `$DOMAIN_NAME` from `.env`.
- `openssl req` flags (`[LOCAL]` `man openssl-req`):
  - `-x509` — output a self-signed certificate instead of a signing request
  - `-noenc` — don't encrypt the key (nginx must read it without a passphrase);
    the modern name of `-nodes`
  - `-newkey rsa:2048` — generate a new 2048-bit RSA key
  - `-days 365` — validity
  - `-subj "/CN=…"` — set the subject non-interactively
- `sed -i …` — replaces the placeholder. On later starts the placeholder is
  already gone, so it does nothing.
- `exec nginx` — `daemon off;` is in the config, so this stays in the foreground → PID 1.

The browser will warn "not trusted" — normal for self-signed. Accept it in the defense.

---

## Checklist

- [ ] `alpine:3.23`, `sh` entrypoint
- [ ] Only `listen 443 ssl`, no port 80
- [ ] `ssl_protocols TLSv1.2 TLSv1.3;` written explicitly
- [ ] `.php` → `wordpress:9000`, static files served directly
- [ ] PID 1 is `nginx: master process`

---

### Quick Reference
- **Packages:** `nginx openssl`
- **Config:** whole `/etc/nginx/nginx.conf` replaced; `daemon off;`
- **TLS:** `listen 443 ssl;` · `ssl_protocols TLSv1.2 TLSv1.3;` · cert in `/etc/nginx/ssl/`
- **Cert:** `openssl req -x509 -noenc -newkey rsa:2048 -days 365 -keyout K -out C -subj "/CN=$DOMAIN_NAME"`
- **PHP:** `location ~ \.php$ { include fastcgi.conf; fastcgi_pass wordpress:9000; }`
- **WP permalinks:** `try_files $uri $uri/ /index.php?$args;`
