# 11 — Bonus (optional)

> ⚠️ "The bonus part will only be assessed if the mandatory part is completed
> **perfectly**." `[S p.15]` — finish 01–10 first.

Rules for every bonus service `[S p.15]`:
- Its own Dockerfile and its own container (same pattern as [00 — Conventions](00-index.md#conventions-the-same-everywhere))
- Its own volume if needed
- You **may open more ports** for bonus services `[S p.15]`

---

## The list `[S p.15]`

| Bonus | What it connects to | Suggested approach `[CHOICE]` | Docs |
|---|---|---|---|
| **Redis cache** for WordPress | wordpress → redis:6379 | `redis` package on Alpine, `exec redis-server` with `daemonize no`; in WordPress, install a Redis object-cache plugin with WP-CLI and set `WP_REDIS_HOST=redis` in `wp-config.php`; add `php84-redis` | https://redis.io/docs/latest/ |
| **FTP server** on the WordPress volume | mounts `wordpress_data` | `vsftpd` package, foreground (`background=NO` in its config), user/password from a secret, passive port range published | `[LOCAL]` `man vsftpd.conf` |
| **Static website** (not PHP) | own container, or served by nginx | plain HTML/CSS/JS served by a tiny server in its own container | — |
| **Adminer** | adminer → mariadb:3306 | Adminer is a single PHP file; run it with php-fpm in its own container, routed via nginx or its own port | https://www.adminer.org/ |
| **Service of your choice** | — | must be justified in the defense `[S p.15]` | — |

`[COMMON]` Redis + FTP + Adminer + static site is the typical set: each one
reuses something you already built (volume, network, php-fpm pattern).

---

## Checklist

- [ ] Mandatory part passes every check in [09](09-validation.md)
- [ ] Each bonus: own Dockerfile, own container, PID 1 = the service
- [ ] New secrets added to `secrets/` and still git-ignored
- [ ] Extra ports documented in README

---

### Quick Reference
- **Gate:** mandatory must be perfect `[S p.15]`
- **Pattern:** same Dockerfile / entrypoint / `exec` convention as the 3 core services
- **Ports:** extra ones allowed for bonus only
