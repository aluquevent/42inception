# 06 — WordPress + php-fpm

Goal: a container with **WordPress + php-fpm only, no nginx** `[S p.7]`, listening
for FastCGI on port 9000 `[S p.9]`, with WordPress installed and **two users**
(admin name without "admin") `[S p.8]`.

Files:
```
srcs/requirements/wordpress/
├── Dockerfile
├── .dockerignore
├── conf/www.conf
├── conf/zz-inception.ini
└── tools/entrypoint.sh
```

---

## 1. Facts this is built on

| Fact | Source |
|---|---|
| Alpine 3.23 has `php83-fpm`, `php84-fpm`, `php85-fpm` | `[PKG]` https://pkgs.alpinelinux.org/packages?name=php*-fpm&branch=v3.23 |
| `php84-fpm` installs `/usr/sbin/php-fpm84`, pool config `/etc/php84/php-fpm.d/www.conf` | `[PKG]` contents of `php84-fpm` (v3.23) |
| `php84` installs `/usr/bin/php` (needed by WP-CLI's `#!/usr/bin/env php`) | `[PKG]` contents of `php84` (v3.23) |
| WordPress recommends PHP 8.4+; required extensions: json, hash, mysqli | `[DOC]` https://make.wordpress.org/hosting/handbook/server-environment/ |
| WP-CLI install: download the phar, `chmod +x`, move to PATH as `wp` | `[DOC]` https://make.wordpress.org/cli/handbook/guides/installing/ |
| php-fpm `listen` accepts `ip:port`; `user` mandatory; `pm` / `pm.max_children` mandatory | `[DOC]` https://www.php.net/manual/en/install.fpm.configuration.php |

`[CHOICE]` **PHP 8.4**: recommended by WordPress and in active support; 8.3 is
security-only (same WordPress page).
⚠️ That page also mentions a crash regression in PHP 8.4.27 (the version Alpine
3.23 ships). php.net's changelog didn't confirm it when checked on 2026-11-04 —
treat it as **unverified**, and if php-fpm crashes randomly, this is the first
thing to look at.

---

## 2. `conf/www.conf`

Replaces Alpine's pool file (convention #5).

```ini
[www]
user  = nobody
group = nobody

listen = 0.0.0.0:9000

pm                   = dynamic
pm.max_children      = 5
pm.start_servers     = 2
pm.min_spare_servers = 1
pm.max_spare_servers = 3
```

**Why each line** (all directives from `[DOC]` php.net FPM configuration):
- `[www]` — pool name. Any name works; `www` is the conventional one.
- `user`/`group = nobody` — unprivileged account for the PHP workers; the master
  stays root only to bind the port. `user` is mandatory. `[CHOICE]` `nobody`
  exists on Alpine by default, so no need to create a user.
- `listen = 0.0.0.0:9000` — the default listens on `127.0.0.1:9000`
  (`[LOCAL]` check the original `www.conf`), which another container can't
  reach. `0.0.0.0` = all interfaces of *this container*. Port 9000 is never
  published to the host, so only the `inception` network can reach it.
  php.net warns "an exposed FastCGI endpoint allows arbitrary code execution" —
  that's exactly why **it's not published**.
- `pm = dynamic` + the 4 numbers — mandatory process-manager settings. Small values
  because it's a local dev site. `[CHOICE]`

### `conf/zz-inception.ini`

```ini
memory_limit = 512M
```

- PHP reads `/etc/php84/php.ini`, then every `.ini` in `/etc/php84/conf.d/`
  **alphabetically**; later files override earlier ones. `[LOCAL]` `php --ini`
  in the container lists them (Alpine's are `00_*`, `01_*`, `02_*`).
- `zz-` prefix → loaded last → our value wins.
- `memory_limit` default is 128M `[DOC]` https://www.php.net/manual/en/ini.core.php#ini.memory-limit.
  With 128M, `wp core download` (WordPress 7.1.4) dies while unzipping:
  `Allowed memory size of 134217728 bytes exhausted … Extractor.php`. The
  container then restart-loops, `/var/www/html` stays empty, and NGINX answers
  **403** ("directory index … is forbidden"). Seen in practice on 2026-11-06.
- Applies to both PHP CLI (`wp`) and php-fpm. `[CHOICE]` 512M = comfortable headroom.

---

## 3. `Dockerfile`

```dockerfile
FROM alpine:3.23

RUN apk add --no-cache \
        php84 php84-fpm php84-mysqli php84-phar php84-curl \
        php84-mbstring php84-iconv php84-openssl \
        curl

RUN curl -o /usr/local/bin/wp \
        https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar \
    && chmod +x /usr/local/bin/wp

COPY conf/www.conf /etc/php84/php-fpm.d/www.conf
COPY conf/zz-inception.ini /etc/php84/conf.d/zz-inception.ini
COPY tools/entrypoint.sh /usr/local/bin/entrypoint.sh
RUN chmod +x /usr/local/bin/entrypoint.sh

WORKDIR /var/www/html

EXPOSE 9000

ENTRYPOINT ["/usr/local/bin/entrypoint.sh"]
```

**Package list — why each:**

| Package | Why |
|---|---|
| `php84`, `php84-fpm` | PHP + the FastCGI process manager |
| `php84-mysqli` | **Required** by WordPress to talk to MariaDB `[DOC]` WP server-environment |
| `php84-phar` | WP-CLI is a `.phar` archive — PHP needs the phar extension to run it `[LOCAL]` remove it and `wp --info` fails |
| `php84-curl`, `php84-openssl` | HTTPS downloads (`wp core download`) — curl/openssl "highly recommended" `[DOC]` WP server-environment |
| `php84-mbstring`, `php84-iconv` | Text encoding; mbstring highly recommended, iconv is a fallback `[DOC]` same page |
| `curl` | Download WP-CLI at build time, as in the WP-CLI install guide |

All exist on v3.23 `[PKG]` https://pkgs.alpinelinux.org/packages?name=php84-*&branch=v3.23.
If WP-CLI ever complains about a missing extension, add `php84-<name>`.

**Notes:**
- Downloading WP-CLI is **not** "pulling a ready-made image" `[S p.7]` — that
  rule is about Docker images. You still build the image yourself.
- `WORKDIR /var/www/html` — the entrypoint runs `wp` here; it's where the
  `wordpress_data` volume is mounted.
- WordPress itself is **not** downloaded at build time, because the volume mounted
  on `/var/www/html` would hide whatever the image put there. It's downloaded on
  first run, straight into the volume. `[CHOICE]`

---

## 4. `tools/entrypoint.sh`

```sh
#!/bin/sh
set -e

DB_PASSWORD="$(cat /run/secrets/db_password)"
WP_ADMIN_PASSWORD="$(cat /run/secrets/wp_admin_password)"
WP_USER_PASSWORD="$(cat /run/secrets/wp_user_password)"

if echo "$WP_ADMIN_USER" | grep -qi 'admin'; then
    echo "wordpress: WP_ADMIN_USER must not contain 'admin'" >&2
    exit 1
fi

if [ ! -f wp-config.php ]; then
    wp core download --allow-root

    wp config create --allow-root \
        --dbname="$MYSQL_DATABASE" \
        --dbuser="$MYSQL_USER" \
        --dbpass="$DB_PASSWORD" \
        --dbhost=mariadb:3306

    wp core install --allow-root \
        --url="https://$DOMAIN_NAME" \
        --title="$WP_TITLE" \
        --admin_user="$WP_ADMIN_USER" \
        --admin_password="$WP_ADMIN_PASSWORD" \
        --admin_email="$WP_ADMIN_EMAIL" \
        --skip-email

    wp user create --allow-root "$WP_USER" "$WP_USER_EMAIL" \
        --role=author \
        --user_pass="$WP_USER_PASSWORD"
fi

chown -R nobody:nobody /var/www/html

exec php-fpm84 -F
```

**Walkthrough:**

1. **Secrets** — convention #4.
2. **Admin-name guard** — `grep -qi admin` (case-insensitive) rejects `admin`,
   `Admin`, `administrator`, `admin-123`… all the forms in `[S p.8]`, because
   they all *contain* "admin". Fails fast with a clear message instead of
   silently breaking a rule.
3. **First-run guard** `[ ! -f wp-config.php ]` — `wp-config.php` only exists
   after setup. On restart → skip to `exec`.
4. **`wp core download`** — fetches WordPress into the current dir (the volume).
5. **`wp config create`** — writes `wp-config.php`. `--dbhost=mariadb:3306`:
   `mariadb` is the **service name**, resolved by Docker's DNS on the
   user-defined network ([02 — network](02-concepts.md#docker-network-vs-host-network--readme-comparison-3)).
   It also tests the DB connection, so MariaDB must be ready → handled by the
   `depends_on: condition: service_healthy` in [08](08-compose-makefile.md).
6. **`wp core install`** — creates the tables + **user 1 = administrator**.
   `--url=https://…` so WordPress generates HTTPS links. `--skip-email`: no mail server.
7. **`wp user create … --role=author`** — **user 2**, not an admin. Two users
   total `[S p.8]`. `[CHOICE]` role `author` (can post, can't administer).
8. **`--allow-root`** — WP-CLI refuses to run as root without it; the entrypoint
   runs as root. `[LOCAL]` run `wp core version` without it in the container and
   read the error.
9. **`chown -R nobody:nobody`** — php-fpm workers run as `nobody` (www.conf) and
   must be able to write uploads/plugins.
10. **`exec php-fpm84 -F`** — `-F` = `--nodaemonize`, stay in foreground → PID 1.
    `[LOCAL]` `php-fpm84 -h`.

WP-CLI command references:
`[DOC]` https://developer.wordpress.org/cli/commands/core/download/ ·
https://developer.wordpress.org/cli/commands/config/create/ ·
https://developer.wordpress.org/cli/commands/core/install/ ·
https://developer.wordpress.org/cli/commands/user/create/

> If a first run fails after `core download` but before `wp-config.php` exists,
> the next run's `core download` will refuse because files are present.
> Fix: `make fclean` and start again.

---

## 5. Check (once the stack runs, see 08)

```sh
docker exec wordpress wp user list --allow-root     # 2 users, one administrator
docker exec wordpress ps                            # PID 1 = php-fpm: master process
docker exec wordpress sh -c 'nc -z mariadb 3306 && echo db reachable'
```

---

## Checklist

- [ ] No nginx in this image
- [ ] php-fpm listens on `0.0.0.0:9000`, port not published to host
- [ ] WordPress installed into the volume on first run only
- [ ] 2 users, admin name has no "admin"
- [ ] PID 1 is php-fpm (master)

---

### Quick Reference
- **Packages:** `php84 php84-fpm php84-mysqli php84-phar php84-curl php84-mbstring php84-iconv php84-openssl curl`
- **WP-CLI:** `curl -o /usr/local/bin/wp <wp-cli.phar url> && chmod +x`
- **Pool:** `/etc/php84/php-fpm.d/www.conf` → `listen = 0.0.0.0:9000`, `user = nobody`
- **PHP ini:** `/etc/php84/conf.d/zz-inception.ini` → `memory_limit = 512M` (else `wp core download` OOMs → 403)
- **Install once:** `core download` → `config create --dbhost=mariadb:3306` → `core install` → `user create --role=author`
- **Run:** `exec php-fpm84 -F`
- **Always:** `--allow-root` (script runs as root)
