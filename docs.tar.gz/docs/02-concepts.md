# 02 — Concepts you must be able to explain

The evaluator will ask "why?". This file is the short theory behind every choice
in the build. It also feeds the comparisons the README must contain `[S p.12]`.

---

## Image vs container

- **Image** = a read-only template built from a `Dockerfile`, made of layers
  (each instruction like `RUN`/`COPY` adds a layer).
- **Container** = a running instance of an image, with a thin writable layer on top.
  Delete the container → that writable layer is gone. That's why data goes in volumes.

`[DOC]` https://docs.docker.com/get-started/docker-overview/

---

## Virtual machine vs Docker  *(README comparison #1)*

| | Virtual machine | Docker container |
|---|---|---|
| Isolates | A full machine (virtual hardware) | A process |
| Kernel | Its own guest kernel | **Shares the host kernel** |
| Boot | An OS boot (seconds–minutes) | A process start (ms–seconds) |
| Size | GBs (full OS) | MBs (just userland + app) |
| Use here | The VM *is* your host `[S p.4]` | One per service `[S p.7]` |

Docker relies on Linux kernel features (namespaces for isolation, cgroups for
resource limits) instead of a hypervisor.
`[DOC]` https://docs.docker.com/get-started/docker-overview/ — "provides a viable,
cost-effective alternative to hypervisor-based virtual machines" and "takes
advantage of several features of the Linux kernel".

The subject's own warning: *"A Docker container is not a virtual machine"* `[S p.8]`.
→ don't treat it like one (no init system, no keeping it alive with hacks).

---

## PID 1 and daemons

This is the most asked topic. The subject explicitly tells you to read about it `[S p.8]`.

**The rule:** a container lives exactly as long as its **PID 1** process.
When PID 1 exits, the container stops.

**Daemon** = a program that forks into the background and lets its parent exit.
In a container that's fatal: the parent *was* PID 1, it exits → container stops.
So every service must run in the **foreground**:

| Service | Foreground mode | Source |
|---|---|---|
| MariaDB | `mariadbd` runs in the foreground by default | `[LOCAL]` start it, it doesn't return |
| php-fpm | `php-fpm84 -F` (`--nodaemonize`) | `[LOCAL]` `php-fpm84 -h` |
| NGINX | `daemon off;` in `nginx.conf` | `[DOC]` https://nginx.org/en/docs/ngx_core_module.html#daemon |

**Why the hacks are banned:** `tail -f /dev/null`, `sleep infinity`, `while true`
make *a dummy* PID 1 that never exits, while the real service runs as a
background daemon. Docker then watches the dummy: if the real service crashes,
the container looks healthy and **never restarts**. Signals (`docker stop`) go
to the dummy, not the service. `[S p.8]`

**Why `exec` in the entrypoint:** the script starts as PID 1. `exec` *replaces*
the shell process with the daemon, so the daemon becomes PID 1 and receives
signals directly.
`[DOC]` https://docs.docker.com/build/building/best-practices/ — the Postgres
entrypoint example uses `exec` so that "the final running application becomes
the container's PID 1".

**Exec form vs shell form:**
```dockerfile
ENTRYPOINT ["/usr/local/bin/entrypoint.sh"]   # exec form: runs directly, is PID 1
ENTRYPOINT /usr/local/bin/entrypoint.sh       # shell form: wrapped in /bin/sh -c
```
We always use exec form. `[DOC]` same best-practices page (JSON array form).

**One concern per container:** `[DOC]` best-practices page — "Each container
should have only one concern." php-fpm and nginx spawning worker processes is
fine; they're still one service.

---

## Docker network vs host network  *(README comparison #3)*

| | User-defined bridge (`inception`) | Host network |
|---|---|---|
| Isolation | Containers get their own network namespace | Container uses the host's network stack directly |
| Name resolution | **Automatic DNS**: `mariadb`, `wordpress` resolve by service name | None — everything is `localhost` |
| Exposure | Only what you publish with `ports:` | Every listening port is on the host |
| Subject | Required `[S p.7]` | **Forbidden** `[S p.8]` |

- `[DOC]` https://docs.docker.com/engine/network/drivers/bridge/ — "User-defined
  bridges provide automatic DNS resolution between containers"; `--link` is "considered legacy".
- `[DOC]` https://docs.docker.com/engine/network/drivers/host/ — the container's
  "network stack isn't isolated from the Docker host".

This is why `fastcgi_pass wordpress:9000` and `--dbhost=mariadb:3306` work:
service name = DNS name.

---

## Docker volumes vs bind mounts  *(README comparison #4)*

| | Named volume | Bind mount |
|---|---|---|
| Managed by | **Docker** (`docker volume ls/inspect/rm`) | You — it's just a host path |
| Declared | `volumes:` top-level + `name:/path` in service | `./host/path:/container/path` |
| Portability | Doesn't depend on host layout | Depends on host directory structure |
| Subject | Required `[S p.7]` | Not allowed for the 2 volumes `[S p.7]` |

- `[DOC]` https://docs.docker.com/engine/storage/volumes/ — "volumes are completely managed by Docker".
- `[DOC]` https://docs.docker.com/engine/storage/bind-mounts/ — "a file or
  directory on the host machine is mounted from the host into a container".

How we keep named volumes **and** put the data in `/home/<login>/data` →
[08 — volumes](08-compose-makefile.md#volumes--the-grey-area).

---

## Secrets vs environment variables  *(README comparison #2)*

| | Environment variable | Docker secret (Compose, file-based) |
|---|---|---|
| Where it lives | In the process environment | A file at `/run/secrets/<name>` |
| Visible via | `docker inspect`, `/proc/<pid>/environ`, child processes, logs | Only inside the services granted it |
| Granularity | Everything in `env_file` goes to the container | **Per service** |
| Use here | Domain, DB name, usernames | All passwords |

- `[DOC]` https://docs.docker.com/compose/how-tos/use-secrets/ — secrets are
  "mounted as a file in `/run/secrets/<secret_name>`"; "Compose grants access to
  secrets on a per-service basis".
- `[DOC]` https://docs.docker.com/engine/swarm/secrets/ — "environment variables
  can unintentionally be leaked between containers".
- Subject: env vars + `.env` mandatory, secrets strongly recommended `[S p.8]`.

Honest caveat for the defense: Compose file secrets (without Swarm) are
bind-mounted files, **not encrypted**. Their win is *scope* (only the services
that list them) and keeping passwords out of `docker inspect`/env. The value
is still read into a shell variable inside the entrypoint at runtime.

---

## How the request flows

```
browser ──HTTPS:443──▶ nginx ──FastCGI:9000──▶ wordpress(php-fpm) ──SQL:3306──▶ mariadb
                         │                          │                           │
                         └──── wordpress_data ──────┘                     mariadb_data
                              (/var/www/html)                            (/var/lib/mysql)
```
Diagram from `[S p.9]`. NGINX mounts the WordPress files too: it serves static
files (CSS, images) itself and only sends `.php` to php-fpm.

---

### Quick Reference
- **Container dies when PID 1 dies** → run daemons in foreground, `exec` them
- **Foreground flags:** `mariadbd` (default) · `php-fpm84 -F` · nginx `daemon off;`
- **Banned keep-alives:** `tail -f`, `sleep infinity`, `while true`, `bash` — they hide crashes from Docker
- **VM** = own kernel; **container** = shared kernel, isolated process
- **Bridge network** = DNS by service name; **host** = no isolation (forbidden)
- **Named volume** = Docker-managed; **bind mount** = raw host path
- **Secret** = file in `/run/secrets`, per service; **env var** = visible in inspect/env
