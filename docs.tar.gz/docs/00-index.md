# Inception — Build Roadmap

Study + build guide for the 42 **Inception** project (subject v5.3, `en.subject.pdf`).
Read the files in order. Each one ends with a checklist — don't move on until it's ticked.

> Replace `<login>` everywhere with your 42 login. It appears in the domain
> (`<login>.42.fr`) and the data path (`/home/<login>/data`).

---

## Reading order

| # | File | You finish it with… |
|---|---|---|
| 01 | [Requirements](01-requirements.md) | Every rule of the subject as a checklist |
| 02 | [Concepts](02-concepts.md) | The theory you must explain in the defense |
| 03 | [VM setup](03-vm-setup.md) | A VM with Docker, the data dirs and the domain |
| 04 | [Layout, .env, secrets](04-layout-env-secrets.md) | The repo skeleton and config/secret files |
| 05 | [MariaDB](05-mariadb.md) | A working database container |
| 06 | [WordPress](06-wordpress.md) | WordPress + php-fpm installed with 2 users |
| 07 | [NGINX](07-nginx.md) | HTTPS (TLS 1.2/1.3) on port 443 |
| 08 | [Compose + Makefile](08-compose-makefile.md) | `make` brings the whole stack up |
| 09 | [Validation](09-validation.md) | Proof that every rule is respected |
| 10 | [Deliverables](10-deliverables.md) | `README.md`, `USER_DOC.md`, `DEV_DOC.md` |
| 11 | [Bonus](11-bonus.md) | (optional) extra services |

Build order is **MariaDB → WordPress → NGINX** because each one depends on the
previous: WordPress needs the database, NGINX needs php-fpm.

---

## Source tags

Every rule or decision carries a tag so you always know *where it comes from*.

| Tag | Meaning |
|---|---|
| `[S p.N]` | Subject PDF, page N. **Mandatory.** |
| `[DOC]` | Official documentation (link next to it). |
| `[PKG]` | Alpine package index, `pkgs.alpinelinux.org`, branch v3.23. |
| `[CHOICE]` | The subject leaves it open — this is the option picked, with the reason. You must be able to defend it. |
| `[COMMON]` | Widespread practice, **not** a subject rule. |
| `[LOCAL]` | Verify yourself by running the given command (inside the container / VM). |

All `[DOC]` and `[PKG]` links were checked on **2026-11-04**. Package versions
move — re-check before the defense.

---

## Conventions (the same everywhere)

These are the rules that keep the 3 services consistent. If you see something
that breaks one of them, it's a bug in the docs — fix it.

1. **Base image:** `FROM alpine:3.23` for every service. `[S p.7]` asks for the
   *penultimate stable* Alpine or Debian. On 2026-11-04 Alpine's latest is 3.24
   and the penultimate is 3.23 `[DOC]` https://alpinelinux.org/releases/.
   ⚠️ Alpine releases twice a year (v3.25 is expected ~Dec 2026). If 3.25 is out
   on your defense day, the penultimate becomes 3.24.
2. **Service folder shape:**
   ```
   requirements/<service>/
   ├── Dockerfile
   ├── .dockerignore
   ├── conf/        # config files that REPLACE the package defaults
   └── tools/
       └── entrypoint.sh
   ```
   Matches the tree shown in `[S p.10]`.
3. **Dockerfile shape:** always the same order: `FROM` → `RUN apk add --no-cache …`
   → `COPY conf/…` → `COPY tools/entrypoint.sh` → `EXPOSE` → `ENTRYPOINT [...]` (exec form).
4. **Entrypoint shape:** `#!/bin/sh` + `set -e` → read secrets with
   `cat /run/secrets/<name>` → **first-run block** guarded by a file check (so a
   restart doesn't re-install) → `exec <daemon in foreground>`.
   - Why `sh` and not `bash`: Alpine ships BusyBox `sh`, not bash. `[CHOICE]`
     (installing bash only to run a script is extra weight).
   - Why `exec`: the daemon becomes PID 1 and receives signals `[DOC]`
     https://docs.docker.com/build/building/best-practices/ (ENTRYPOINT section).
5. **Config files:** a whole file in `conf/` is `COPY`'d over the default. No
   `sed` patching of package files in the Dockerfile. The *only* runtime
   substitution is the domain name in NGINX (it comes from `.env`). `[CHOICE]`:
   a full file is readable in the defense; a chain of `sed` isn't.
6. **Data split:** non-sensitive settings → `srcs/.env`. Passwords → one file per
   value in `secrets/`, mounted by Compose at `/run/secrets/<name>`. `[S p.8]`
7. **Naming:** service name = image name = container name. Images are tagged
   `:inception`, never `:latest`. `[S p.7]` `[S p.8]`
8. **Logs:** daemons log to stdout/stderr, so `docker logs <service>` works. `[COMMON]`

---

## Progress

- [ ] 01 Requirements read
- [ ] 02 Concepts understood (can explain without notes)
- [ ] 03 VM ready
- [ ] 04 Skeleton + `.env` + secrets
- [ ] 05 MariaDB container works alone
- [ ] 06 WordPress installs against MariaDB
- [ ] 07 NGINX serves the site over HTTPS
- [ ] 08 `make` / `make fclean` / `make re` work from zero
- [ ] 09 Every validation check passes
- [ ] 10 README / USER_DOC / DEV_DOC written
- [ ] 11 Bonus (only if mandatory is perfect)

---

### Quick Reference
- **Order:** read 01→02, build 03→08, check 09, write 10
- **Base image:** `alpine:3.23` (re-check penultimate before defense)
- **Tags:** `[S]` mandatory · `[DOC]` official · `[CHOICE]` defend it · `[COMMON]` not required · `[LOCAL]` run it
- **Pattern per service:** `Dockerfile` + `conf/` + `tools/entrypoint.sh` → `exec` daemon
- **Secrets:** `secrets/*.txt` → `/run/secrets/*` ; config: `srcs/.env`
