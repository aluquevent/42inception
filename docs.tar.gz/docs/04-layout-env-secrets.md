# 04 — Repo layout, `.env`, secrets

Goal: the skeleton exists, `.env` holds the non-sensitive config, `secrets/`
holds the passwords, and **git can never see either of them**.

---

## 1. Skeleton

```sh
mkdir -p secrets
mkdir -p srcs/requirements/{mariadb,wordpress,nginx}/{conf,tools}
touch srcs/requirements/{mariadb,wordpress,nginx}/{Dockerfile,.dockerignore}
git mv srcs/requirements/nginx/tools/script.sh srcs/requirements/nginx/tools/entrypoint.sh
```

Tree target: [01 — Target repo tree](01-requirements.md#target-repo-tree). Shape
per service: [00 — Conventions](00-index.md#conventions-the-same-everywhere) #2.

### `.dockerignore`

Each service's build context is its own folder (`build: requirements/<service>`),
so there's little to ignore. Keep the file (it's in the subject's tree `[S p.10]`)
with something like:

```
*.md
.git
```
`[DOC]` https://docs.docker.com/build/concepts/context/#dockerignore-files

---

## 2. `.gitignore`

```gitignore
.env
secrets/
```

- `.env` (no slash) matches `srcs/.env` anywhere in the tree, but **not**
  `.env.example` — that one is meant to be committed.
- `secrets/` keeps every password file out. `[S p.8]` `[S p.10]`: credentials in
  the repo = failure.

Check before every push:
```sh
git status --ignored     # .env and secrets/ must be listed as ignored
git ls-files | grep -Ei 'secret|\.env$'   # must print nothing (except .env.example)
```

---

## 3. `srcs/.env` — non-sensitive config

`[S p.8]` makes `.env` mandatory; `[S p.10]` shows it in `srcs/` starting with
`DOMAIN_NAME`. Compose reads `srcs/.env` automatically for `${VAR}` substitution
because it sits next to `docker-compose.yml`, and we also pass it to the
containers with `env_file:` (see [08](08-compose-makefile.md)).

Commit this as `srcs/.env.example`, then `cp srcs/.env.example srcs/.env`:

```sh
DOMAIN_NAME=<login>.42.fr
DATA_PATH=/home/<login>/data

MYSQL_DATABASE=wordpress
MYSQL_USER=wpuser

WP_TITLE=Inception
# Admin name must NOT contain "admin" in any case [S p.8]
WP_ADMIN_USER=<login>_boss
WP_ADMIN_EMAIL=<login>@student.42.fr
WP_USER=<login>_writer
WP_USER_EMAIL=writer@<login>.42.fr
```

Rules for this file:
- **No passwords.** Ever. They go in `secrets/`.
- Plain `KEY=value`, no quotes, no spaces around `=`, comments on their own line.
  Reason: the **Makefile also reads it** with `include` (see 08), and Make and
  Compose agree on this simple form. `[CHOICE]`
- Variable names: `MYSQL_*` follows the subject's example `[S p.10]`.

`[CHOICE]` Why `.env` is git-ignored even without passwords: usernames and emails
are still credentials-adjacent, and `[S p.10]` says to keep credentials local.
The committed `.env.example` documents the keys.

---

## 4. Secrets

`[S p.8]` strongly recommends Docker secrets; `[S p.10]` shows a `secrets/` folder at the root.

`[CHOICE]` **One value per file** (instead of the example's single
`credentials.txt`). Reason: each service is granted exactly the secrets it needs,
and the entrypoint reads each one with a plain `cat` — no parsing.

| File | Used by | Purpose |
|---|---|---|
| `secrets/db_root_password.txt` | mariadb | MariaDB `root` password |
| `secrets/db_password.txt` | mariadb, wordpress | password of `$MYSQL_USER` |
| `secrets/wp_admin_password.txt` | wordpress | WP admin user password |
| `secrets/wp_user_password.txt` | wordpress | WP second user password |

Generate them:
```sh
for s in db_root_password db_password wp_admin_password wp_user_password; do
    openssl rand -base64 18 > "secrets/$s.txt"
done
chmod 600 secrets/*.txt
```

- base64 output only has `A-Z a-z 0-9 + / =` → safe inside SQL single quotes and
  shell double quotes. `[CHOICE]`
- The trailing newline is harmless: `$(cat file)` strips trailing newlines
  `[DOC]` POSIX command substitution — `[LOCAL]` `man sh`, "Command Substitution".

How Compose delivers them: declared at the top level with `file:`, granted per
service, mounted at `/run/secrets/<name>`.
`[DOC]` https://docs.docker.com/compose/how-tos/use-secrets/

How a script reads one (pattern used in every entrypoint):
```sh
DB_PASSWORD="$(cat /run/secrets/db_password)"
```

---

## Checklist

- [ ] Skeleton matches the target tree
- [ ] `script.sh` renamed to `entrypoint.sh`
- [ ] `.gitignore` has `.env` and `secrets/`
- [ ] `srcs/.env.example` committed, `srcs/.env` created locally
- [ ] 4 secret files generated, `git status --ignored` shows them ignored
- [ ] `WP_ADMIN_USER` contains no "admin"

---

### Quick Reference
- **`.env`** → `srcs/.env`, `KEY=value`, no secrets, git-ignored; commit `.env.example`
- **Secrets** → `secrets/<name>.txt`, one value per file, `chmod 600`, git-ignored
- **Generate:** `openssl rand -base64 18 > secrets/<name>.txt`
- **Read in script:** `VAR="$(cat /run/secrets/<name>)"`
- **Verify:** `git status --ignored` · `git ls-files | grep -Ei 'secret|\.env$'`
