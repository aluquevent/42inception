# 09 — Validation (prove every rule)

Run all of this **in the VM, from a clean state**, before booking the defense.
Each check maps to a rule in [01](01-requirements.md).

`[COMMON]` Evaluators often start by wiping Docker on the VM. Make sure your
project survives that (`make` from zero). Check your campus's evaluation sheet
for its exact commands — they aren't in the subject.

```sh
make fclean
make
```

---

## Structure & files

| Check | Command | Expect | Rule |
|---|---|---|---|
| Makefile at root, config in `srcs/` | `ls; ls srcs` | as in [01 tree](01-requirements.md#target-repo-tree) | `[S p.4]` |
| No secrets in git | `git ls-files \| grep -Ei 'secret\|\.env$'` | nothing | `[S p.8]` |
| No password in Dockerfiles | `grep -rni pass srcs/requirements/*/Dockerfile` | nothing | `[S p.8]` |
| No `latest` | `grep -rn latest srcs; docker images` | no `latest` for our images | `[S p.8]` |
| Base image | `grep -rn '^FROM' srcs/requirements` | `alpine:3.23` (penultimate **today**) | `[S p.7]` |
| No hacks | `grep -rnE 'tail -f\|sleep infinity\|while true\|bash' srcs` | nothing | `[S p.8]` |
| No host net / links | `grep -rnE 'network_mode\|links' srcs` | nothing | `[S p.8]` |

## Containers

| Check | Command | Expect | Rule |
|---|---|---|---|
| 3 containers up | `docker ps` | `nginx`, `wordpress`, `mariadb` | `[S p.7]` |
| Image = service name | `docker images` | `nginx:inception`, `wordpress:inception`, `mariadb:inception` | `[S p.7]` |
| PID 1 is the daemon | `docker exec <svc> ps` | PID 1 = `mariadbd` / `php-fpm: master` / `nginx: master` | `[S p.8]` |
| No nginx in WP/DB | `docker exec wordpress which nginx` | nothing | `[S p.7]` |
| Restart on crash | `docker exec nginx nginx -s stop; sleep 3; docker ps` | nginx back up, `docker inspect -f '{{.RestartCount}}' nginx` ≥ 1 | `[S p.7]` |

## Network & TLS

| Check | Command | Expect | Rule |
|---|---|---|---|
| Network exists | `docker network inspect inception` | 3 containers attached | `[S p.7]` |
| Only 443 published | `docker ps --format '{{.Names}} {{.Ports}}'` | only nginx → `0.0.0.0:443->443/tcp` | `[S p.8]` |
| HTTP refused | `curl -I http://<login>.42.fr` | connection refused | `[S p.8]` |
| HTTPS works | `curl -kI https://<login>.42.fr` | `HTTP/1.1 200` (or 30x) | `[S p.8]` |
| TLS 1.2 ok | `openssl s_client -connect <login>.42.fr:443 -tls1_2 < /dev/null` | handshake OK | `[S p.7]` |
| TLS 1.3 ok | `openssl s_client -connect <login>.42.fr:443 -tls1_3 < /dev/null` | handshake OK | `[S p.7]` |
| TLS 1.1 refused | `openssl s_client -connect <login>.42.fr:443 -tls1_1 < /dev/null` | fails (or "no protocols available" — your client also refuses it, still a pass) | `[S p.7]` |
| Domain | open `https://<login>.42.fr` in the VM browser | WordPress site | `[S p.8]` |

`[DOC]` `openssl s_client` flags: `[LOCAL]` `man openssl-s_client`.

## Data

| Check | Command | Expect | Rule |
|---|---|---|---|
| Named volumes | `docker volume ls` | `mariadb_data`, `wordpress_data` | `[S p.7]` |
| Stored in `/home/<login>/data` | `docker volume inspect mariadb_data` · `ls /home/<login>/data/*` | `device` path + files | `[S p.7]` |
| DB content | `docker exec -it mariadb mariadb -u root -p` → `SHOW DATABASES;` | `wordpress` | `[S p.7]` |
| Root needs password | `docker exec mariadb mariadb -u root -e 'select 1'` | Access denied | `[COMMON]` |
| 2 WP users | `docker exec wordpress wp user list --allow-root` | 2 rows, one `administrator`, name w/o "admin" | `[S p.8]` |
| Persistence | write a post / comment → `make down && make` (or reboot the VM) | post still there | `[S p.7]` |

---

## Prepare for the live modification `[S p.16]`

The subject says it may ask for "a minor behavior change, a few lines of code to
write or rewrite, or an easy-to-add feature". `[COMMON]` drills — practice each
until you can do it without notes:

- [ ] Change the published port (e.g. 443 → 8443) — touch `ports:` only, explain why nginx.conf stays the same
- [ ] Allow only TLSv1.3 — edit `ssl_protocols`, prove it with `s_client -tls1_2`
- [ ] Add a third WordPress user via the entrypoint (and explain why it won't run on an existing volume)
- [ ] Change the site title / domain through `.env`
- [ ] Rename the DB user — what else must change, and why `make fclean` is needed
- [ ] Explain every line of any file the evaluator points at (AI rules `[S p.5–6]`)

---

### Quick Reference
- **Reset + run:** `make fclean && make`
- **PID 1:** `docker exec <svc> ps`
- **TLS:** `openssl s_client -connect <login>.42.fr:443 -tls1_2|-tls1_3|-tls1_1 < /dev/null`
- **Ports:** `docker ps --format '{{.Names}} {{.Ports}}'`
- **Users:** `docker exec wordpress wp user list --allow-root`
- **Volumes:** `docker volume inspect <name>` → `device`
- **Crash test:** `docker exec nginx nginx -s stop` → `RestartCount` ≥ 1
