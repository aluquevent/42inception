# 01 — Requirements (the subject as a checklist)

Everything here is **mandatory**. Each line points to its page in `en.subject.pdf`.
Come back to this file before the defense and tick every box.

---

## General

- [ ] The whole project runs inside a **Virtual Machine** `[S p.4]` `[S p.7]`
- [ ] All configuration files live in `srcs/` `[S p.4]`
- [ ] A `Makefile` at the repo root sets up everything by building the images through `docker-compose.yml` `[S p.4]`
- [ ] Uses `docker compose` `[S p.7]`

## Images & containers

- [ ] One service = one dedicated container `[S p.7]`
- [ ] Each image has the **same name as its service** `[S p.7]`
- [ ] Built from the **penultimate stable** Alpine or Debian `[S p.7]` → we use `alpine:3.23` (see [00-index](00-index.md#conventions-the-same-everywhere))
- [ ] You write your own Dockerfiles, one per service, called by `docker-compose.yml`, called by the Makefile `[S p.7]`
- [ ] **No ready-made images** pulled, no DockerHub images (Alpine/Debian excepted) `[S p.7]`
- [ ] The `latest` tag is forbidden `[S p.8]`
- [ ] No password in any Dockerfile `[S p.8]`

## The three services

- [ ] **NGINX** container, TLSv1.2 or TLSv1.3 only `[S p.7]`
- [ ] **WordPress + php-fpm** container (installed and configured), **without nginx** `[S p.7]`
- [ ] **MariaDB** container, **without nginx** `[S p.7]`
- [ ] NGINX is the **only entrypoint**, on **port 443 only**, TLSv1.2/1.3 `[S p.8]`
- [ ] Ports in the diagram: NGINX ↔ WordPress on **9000**, WordPress ↔ DB on **3306** `[S p.9]`

## Storage

- [ ] One volume for the WordPress **database** `[S p.7]`
- [ ] One volume for the WordPress **website files** `[S p.7]`
- [ ] Both are **Docker named volumes** — "Bind mounts are not allowed for these volumes" `[S p.7]`
- [ ] Both store their data in `/home/<login>/data` on the host `[S p.7]` `[S p.8]`

> ⚠️ The last two lines pull in opposite directions. How we satisfy both is
> explained in [08 — volumes](08-compose-makefile.md#volumes--the-grey-area).

## Network

- [ ] A `docker-network` connects the containers `[S p.7]`
- [ ] `network: host`, `--link` and `links:` are **forbidden** `[S p.8]`
- [ ] The `network` line must be present in `docker-compose.yml` `[S p.8]`

## Process rules

- [ ] Containers **restart on crash** `[S p.7]`
- [ ] No infinite-loop hacks as command, entrypoint, or inside entrypoint scripts: `tail -f`, `bash`, `sleep infinity`, `while true` `[S p.8]`
- [ ] Read about **PID 1** and Dockerfile best practices `[S p.8]` → see [02 — Concepts](02-concepts.md#pid-1-and-daemons)

## WordPress

- [ ] **Two users** in the WordPress database, one is the administrator `[S p.8]`
- [ ] The admin username must **not contain** `admin` / `Admin` / `administrator` / `Administrator` (e.g. `admin-123` is also refused) `[S p.8]`

## Domain

- [ ] `<login>.42.fr` points to your local IP `[S p.8]`

## Configuration & secrets

- [ ] Environment variables are **mandatory** `[S p.8]`
- [ ] A `.env` file is **mandatory** (in `srcs/`, per the tree) `[S p.8]` `[S p.10]`
- [ ] Docker secrets are **strongly recommended** for confidential data `[S p.8]`
- [ ] **Any credential in the Git repo = project failure** `[S p.8]` `[S p.10]`

## Documentation

- [ ] `README.md` at the root, in English, with the required sections `[S p.12–13]`
- [ ] `USER_DOC.md` at the root `[S p.14]`
- [ ] `DEV_DOC.md` at the root `[S p.14]`

→ templates in [10 — Deliverables](10-deliverables.md).

## Defense

- [ ] You can explain every file (AI rules) `[S p.5–6]`
- [ ] Be ready for a small **live modification** `[S p.16]`
- [ ] Bonus is only graded if mandatory is **perfect** `[S p.15]`

---

## Target repo tree

Adapted from the example in `[S p.10]`. `[CHOICE]` the secret files are split
one-value-per-file instead of the example's single `credentials.txt` — see
[04](04-layout-env-secrets.md#4-secrets).

```
inception/
├── Makefile
├── README.md
├── USER_DOC.md
├── DEV_DOC.md
├── docs/                         # this roadmap
├── secrets/                      # git-ignored
│   ├── db_root_password.txt
│   ├── db_password.txt
│   ├── wp_admin_password.txt
│   └── wp_user_password.txt
└── srcs/
    ├── .env                      # git-ignored
    ├── .env.example              # committed, no secrets
    ├── docker-compose.yml
    └── requirements/
        ├── mariadb/   { Dockerfile, .dockerignore, conf/, tools/ }
        ├── wordpress/ { Dockerfile, .dockerignore, conf/, tools/ }
        └── nginx/     { Dockerfile, .dockerignore, conf/, tools/ }
```

---

## What's wrong in the current repo (2026-11-04)

| Problem | Rule | Fix in |
|---|---|---|
| `nginx/Dockerfile` uses `alpine:3.22` | penultimate = 3.23 `[S p.7]` | 07 |
| `tools/script.sh` starts with `#!/bin/bash` — no bash on Alpine | convention #4 | 07 (rename to `entrypoint.sh`) |
| Volumes point to `/Users/asier/...` | must be `/home/<login>/data` `[S p.7]` | 08 |
| `nginx` service has no `image:`; `image: wordpress` / `mariadb` imply `:latest` | name = service, no latest `[S p.7–8]` | 08 |
| `wordpress`/`mariadb` have no network, restart, volumes | `[S p.7–8]` | 08 |
| `.gitignore` doesn't cover `secrets/` | credentials in git = fail `[S p.8]` | 04 |
| No Makefile, no `wordpress/`, no root docs | `[S p.4]` `[S p.7]` `[S p.12–14]` | 04–10 |

---

### Quick Reference
- **Only door in:** NGINX, port 443, TLS 1.2/1.3
- **Internal ports:** wordpress:9000 (FastCGI), mariadb:3306 (SQL)
- **Forbidden:** ready-made images, `latest`, `network: host`, `links`, `tail -f` / `sleep infinity` / `while true` / `bash` as keep-alive, passwords in Dockerfiles or git
- **Required:** VM, Makefile, `srcs/`, `.env`, named volumes in `/home/<login>/data`, restart on crash, 2 WP users (admin name w/o "admin"), `<login>.42.fr`
